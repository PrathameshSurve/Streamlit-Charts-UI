import streamlit as st
import pandas as pd
import plotly.express as px
import jwt
from jwt import PyJWTError

def render_machine_dashboard():
    st.header("Multi-Level Visualization of Sales Data")

    # JWT configuration (if required)
    JWT_SECRET = "7f946cd88c7b6a4b9a1cc2cf824cc604170aaaad2fc19edf4edd82ba82ded244500d0206d5c6487979a4f08a1a7ef36b3acc453d5b6187007bddea8cc06e7be8"
    JWT_ALGORITHM = "SHA512"

    def decode_jwt(token: str):
        try:
            decoded_token = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
            return decoded_token
        except PyJWTError as e:
            st.error(f"Invalid token: {e}")
            return None

    token = st.query_params.get("token", [""])[0]

    if token:
        decoded_token = decode_jwt(token)
        if decoded_token:
            st.write("JWT Token:", token)
            st.write("Decoded Token:", decoded_token)
        else:
            st.error("Invalid or expired token.")
    else:
        st.warning("No token provided. Pass the token as a query parameter or in headers.")


    # ODS file path
    ods_file_path = '/home/prathamesh/Downloads/instagoTestExcelSheet.ods'

    # Function to read ODS file
    def read_ods_file(file_path):
        try:
            sheets = pd.read_excel(file_path, sheet_name=None, engine='odf')
            first_sheet = list(sheets.values())[0]
            return first_sheet
        except Exception as e:
            st.error(f"Error reading ODS file: {e}")
            return None

    # Read data
    data_df = read_ods_file(ods_file_path)

    if data_df is not None:
        st.write("Data Loaded Successfully:")
        st.write(data_df)

        # Calculate the amount
        if 'mrp' in data_df.columns and 'qty' in data_df.columns:
            data_df['amount'] = data_df['mrp'] * data_df['qty']

            # Prepare the grouping: Branch > Machine > Product
            grouped_data = data_df.groupby(['branch', 'machineid', 'product'], as_index=False)['amount'].sum()

            # Prepare labels, parents, and values for the sunburst chart
            labels = []
            parents = []
            values = []

            # Add Branch nodes (top-level)
            branches = grouped_data['branch'].unique()
            for branch in branches:
                labels.append(branch)
                parents.append('')
                branch_total = grouped_data[grouped_data['branch'] == branch]['amount'].sum()
                values.append(branch_total)

            # Add Machine nodes under each branch
            for branch in branches:
                machines = grouped_data[grouped_data['branch'] == branch]['machineid'].unique()
                for machine in machines:
                    labels.append(machine)
                    parents.append(branch)
                    machine_total = grouped_data[(grouped_data['branch'] == branch) & (grouped_data['machineid'] == machine)]['amount'].sum()
                    values.append(machine_total)

                    # Add Product nodes under each machine
                    products = grouped_data[(grouped_data['branch'] == branch) & (grouped_data['machineid'] == machine)]['product'].unique()
                    for product in products:
                        labels.append(product)
                        parents.append(machine)
                        product_total = grouped_data[
                            (grouped_data['branch'] == branch) & 
                            (grouped_data['machineid'] == machine) & 
                            (grouped_data['product'] == product)
                        ]['amount'].sum()
                        values.append(product_total)

            # Create the Plotly Sunburst chart
            fig = px.sunburst(
                names=labels,
                parents=parents,
                values=values,
                title="Sales Data Hierarchy by Branch, Machine, and Product",
                width=800,
                height=600
            )

            # Display the chart
            st.plotly_chart(fig)

        else:
            st.error("Columns 'mrp' or 'qty' are missing from the data.")
    else:
        st.error("No data to display")
