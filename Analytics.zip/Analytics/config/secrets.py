# config/secrets.py

API_KEY = "https://...."
