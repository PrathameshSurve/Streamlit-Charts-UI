APP_NAME = "Analytics Dashboard"
API_BASE_URL = "https://api.yourservice.com"
