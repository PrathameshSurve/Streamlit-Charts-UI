import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px

def render_revenue_dashboard():
  st.header("Revenue Dashboard")

  tab1, tab2, tab3, tab4 = st.tabs(["Screen 1", "Screen 2", "Screen 3", "Screen 4"])

  #tab 1
  with tab1:

    row1_col1, row1_col2 = st.columns([2, 3])

    with row1_col1:

      row1_col1_row1_col1, row1_col1_row1_col2 = st.columns([1, 1])

      with row1_col1_row1_col1:
        st.metric(label="FTM", value="69.72 L", delta="1.2%")
        st.metric(label="YTD", value="190.8 L", delta="9.87%")

      with row1_col1_row1_col2:
        st.metric(label="ARPU", value="19.8 K", delta="-9.87%")
        st.metric(label="RFID", value="77.8 K", delta="-3.47%")
        st.metric(label="NON-RFID", value="18.8 K", delta="-1.93%")

    with row1_col2:

      st.write('Branch-wise Revenue Summary in Lacs')
      
      df_revenue = pd.DataFrame({
      "Branch Name": ["BANGALORE", "BARODA", "DELHI", "HYDERABAD", "MUMBAI", "PUNE", "TOTAL"],
      "YTD Revenue": [52.33, 17.39, 41.09, 173.41, 399.26, 249.96, 933.45],
      "Last Month Revenue": [8.74, 3.45, 6.78, 26.86, 59.74, 37.13, 142.70],
      "FTM Revenue": [3.75, 0.97, 2.97, 13.98, 29.61, 18.42, 69.72],
      "MRR": [8.72, 2.90, 6.85, 28.90, 66.54, 41.66, 155.57],
      "FY 2025 Exit": [104.66, 34.78, 82.18, 346.82, 798.53, 499.93, 1866.89]
      })

      st.write(df_revenue)

    row2_col1, row2_col2 = st.columns([2, 3])

    with row2_col1:

      months = ["Apr-24", "May-24", "Jun-24", "Jul-24", "Aug-24", "Sep-24"]

      random_data = np.random.randint(0, 25001, size=len(months))

      df_graph = pd.DataFrame({
          "Month": months,
          "Revenue": random_data
      })

      fig = px.bar(
          df_graph,
          x="Month",
          y="Revenue",
          title="ARPU Month on Month Trend",
          labels={"Month": "Month", "Revenue": "Revenue"}
      )

      fig.update_traces(width=0.4, marker_color="#20B2AA")
      st.plotly_chart(fig)

    with row2_col2:

      months = ["Apr-24", "May-24", "Jun-24", "Jul-24", "Aug-24", "Sep-24", "Oct-24"]

      random_data = np.random.randint(0, 12, size=len(months))

      df_graph = pd.DataFrame({
          "Month": months,
          "Revenue": random_data
      })

      fig = px.bar(
          df_graph,
          x="Month",
          y="Revenue",
          title="Branch-wise Month on Month Revenue Summary in Lacs",
          labels={"Month": "Month", "Revenue": "Revenue"}
      )

      fig.update_traces(width=0.4, marker_color="#20B2AA")
      st.plotly_chart(fig)

  #tab 2
  with tab2:

    row1_col1, row1_col2 = st.columns([1, 1])

    with row1_col1:

      data = {
      "Customer Name": [
          "Mastercard - Pune", "Google - SAR 1", "Amazon", "Google - SAR 3",
          "Google - SAR 1", "RIL - Ghansoli", "Citibank", "Atlas University",
          "WPP", "Aurum Park"
      ],
      "Avm Count": [11, 10, 122, 8, 10, 13, 29, 6, 15, 4],
      "FTM Sales (L)": [18.94, 11.13, 8.64, 5.54, 11.13, 7.72, 6.45, 3.82, 4.40, 2.92],
      "YTD Sales (L)": [113.64, 65.29, 53.16, 51.85, 65.29, 46.32, 38.70, 8.06, 26.93, 16.90]
      }

      df_customers = pd.DataFrame(data)

      st.write("Customer Sales Data")
      st.dataframe(df_customers)
    
    with row1_col2:

      months = ["Apr-24", "May-24", "Jun-24", "Jul-24", "Aug-24", "Sep-24"]

      random_data = np.random.randint(0, 12000, size=len(months))

      df_graph = pd.DataFrame({
          "Month": months,
          "Revenue": random_data
      })

      fig = px.bar(
          df_graph,
          x="Month",
          y="Revenue",
          title="Branch-wise Month on Month ARPU Summary",
          labels={"Month": "Month", "Revenue": "Revenue"}
      )

      fig.update_traces(width=0.4, marker_color="#20B2AA")
      st.plotly_chart(fig)

    row2_col1, row2_col2 = st.columns([1, 1])

    with row2_col1:

      days = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31']

      random_data = np.random.randint(0, 160000, size=len(days))

      df_graph = pd.DataFrame({
          "Days": days,
          "Revenue": random_data
      })

      fig = px.bar(
          df_graph,
          x="Days",
          y="Revenue",
          title="Day Wise Sales Trend",
          labels={"Days": "Days", "Revenue": "Revenue"}
      )

      fig.update_traces(width=0.4, marker_color="#20B2AA")
      st.plotly_chart(fig)

    with row2_col2:
      week = ["Week 1", "Week 2", "Week 3"]
      random_data_sep = np.random.uniform(0, 3.5, size=len(week))
      random_data_oct = np.random.uniform(0, 3.5, size=len(week))
      df_graph = pd.DataFrame({
          "Weeks": week,
          "Sep-24": random_data_sep,
          "Oct-24": random_data_oct
      })
      df_melted = df_graph.melt(id_vars="Weeks", value_vars=["Sep-24", "Oct-24"],
                                var_name="Month", value_name="Revenue")
      fig = px.bar(
          df_melted,
          x="Revenue",
          y="Weeks",
          color="Month",
          title="Month-wise Week on Week Sales Trend",
          labels={"Weeks": "Weeks", "Revenue": "Revenue"},
          text="Revenue",
          color_discrete_map={
            "Sep-24": "#20B2AA",
            "Oct-24": "#32CD32"
          }
      )
      fig.update_traces(width=0.4, textposition='inside')
      st.plotly_chart(fig, horizontal=True)

  #tab 3
  with tab3:
    row1_col1, row1_col2, row1_col3 = st.columns([1, 1, 1])

    with row1_col1:
      labels = ["endswifter", "Vendvittor", "Touchscreen", "Vendekin", "Cash"]
      random_percentages = np.random.rand(len(labels))
      random_percentages = random_percentages / random_percentages.sum() * 100

      df_pie = pd.DataFrame({
          "Labels": labels,
          "Values": random_percentages
      })

      fig = px.pie(
          df_pie,
          names='Labels',
          values='Values',
          title='Technology Wise Machine Count',
          color_discrete_sequence=px.colors.qualitative.Plotly
      )

      st.plotly_chart(fig)

    with row1_col2:
      labels = ["Cash", "RFID", "Instago Wallet", "Corp_Wallet", "Cash", "Total"]
      random_values = np.random.randint(0, 201, size=len(labels))

      df_doughnut = pd.DataFrame({
          "Labels": labels,
          "Values": random_values
      })

      df_doughnut['Percentage'] = (df_doughnut['Values'] / df_doughnut['Values'].sum()) * 100
      df_doughnut['Label Text'] = df_doughnut.apply(lambda row: f"{row['Labels']}: {row['Values']} ({row['Percentage']:.1f}%)", axis=1)

      fig = px.pie(
          df_doughnut,
          names='Label Text',
          values='Values',
          title='Random Value Distribution - Doughnut Chart',
          color_discrete_sequence=px.colors.qualitative.Plotly,
          hole=0.6
      )

      st.plotly_chart(fig)

    with row1_col3:
      st.subheader('1 more Inforgraphics to be included')

    row2_col1, row2_col2 = st.columns([2, 3])

    with row2_col1:
      labels = ["endswifter", "Vendvittor", "Touchscreen", "Vendekin", "Cash", "Total"]
      random_percentages = np.random.rand(len(labels))
      random_percentages = random_percentages / random_percentages.sum() * 100

      df_pie = pd.DataFrame({
          "Labels": labels,
          "Values": random_percentages
      })

      fig = px.pie(
          df_pie,
          names='Labels',
          values='Values',
          title='Technology Wise Revenue Split',
          color_discrete_sequence=px.colors.qualitative.Plotly
      )

      st.plotly_chart(fig)

    with row2_col2:
      file_path = "/home/prathamesh/Downloads/techwiseRevenueChartData.ods"
      sheet_name = "Sheet1"
      df = pd.read_excel(file_path, sheet_name=sheet_name, engine='odf')
      df_melted = df.melt(id_vars=["Payment"], var_name="Date", value_name="Value")

      fig = px.bar(
          df_melted,
          x="Date",
          y="Value",
          color="Payment",
          barmode="group",
          labels={"Date": "Date", "Value": "Revenue", "Payment": "Payment Method"},
          title="Technology Wise Revenue Split Month on Month",
      )

      st.plotly_chart(fig)

  #tab 4
  with tab4:
    col1, col2 = st.columns([1,1])

    with col1:
      st.write("Top 25 High Sales Performing Machine wise branchwise")

      columns = ["Branch Name", "AVM No.", "Machine Name", "FTM Sales", "YTD Sales"]
      empty_data = pd.DataFrame(columns=columns)
      st.dataframe(empty_data)
    
    with col2:
      st.write("Top 25 Least Sales Performing Machine wise branchwise")

      columns = ["Branch Name", "AVM No.", "Machine Name", "FTM Sales", "YTD Sales"]
      empty_data = pd.DataFrame(columns=columns)
      st.dataframe(empty_data)