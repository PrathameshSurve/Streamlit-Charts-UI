import streamlit as st

def create_sidebar():
    st.sidebar.title("Analytics Dashboard")
    
    # Sidebar sections for navigation
    menu = st.sidebar.radio(
        "Go to",
        (
         "Revenue",
         "Product",
         "Operations",
         "Machine",
         "Technical",
         "User Metrics"
        ),
        index=0  # Default to 'Revenue'
    )
    
    # Additional sidebar elements (e.g., filters or information)
    st.sidebar.markdown("### Filter Options")
    filter_date = st.sidebar.date_input("Select Date Range", [])
    # Add more filters or widgets as needed
    
    return menu, filter_date

