import streamlit as st
from components.layout import create_sidebar
from pages.Dashboard.revenue.dashboard import render_revenue_dashboard
from pages.Dashboard.machine.dashboard import render_machine_dashboard
# from pages.Dashboard.operations.dashboard import render_operations_dashboard
# from pages.Dashboard.product.dashboard import render_product_dashboard
# from pages.Dashboard.technical.dashboard import render_technical_dashboard
# from pages.Dashboard.usermatrics.dashboard import render_user_metrics_dashboard
st.set_page_config(layout="wide")

hide_streamlit_style = """
<style>
    #root > div:nth-child(1) > div > div > div > div > section > div {padding-top: 0rem;}
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header[data-testid="stHeader"] {
        display: none;
    }

</style>
"""
st.markdown(hide_streamlit_style, unsafe_allow_html=True)

selected_page, filter_date = create_sidebar()

# Main section rendering based on selected page
if selected_page == "Revenue":
    render_revenue_dashboard()
elif selected_page == "Machine":
    render_machine_dashboard()
# elif selected_page == "Operations":
#     render_operations_dashboard()
# elif selected_page == "Product":
#     render_product_dashboard()
# elif selected_page == "Technical":
#     render_technical_dashboard()
# elif selected_page == "User Metrics":
#     render_user_metrics_dashboard()

